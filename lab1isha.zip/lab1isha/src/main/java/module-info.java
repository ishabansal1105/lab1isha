module com.example.lab1isha {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;
    requires java.sql;

    opens com.example.lab1isha to javafx.fxml;
    exports com.example.lab1isha;
}