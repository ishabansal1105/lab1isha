package com.example.lab1isha;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {
    public Label welcomeText;
    @FXML
    private TableView<student> tableView;
    @FXML
    private TableColumn<student, Integer> ID;
    @FXML
    private TableColumn<student, String> name;
    @FXML
    private TableColumn<student, Date> DOB;
    @FXML
    private TableColumn<student, Integer> phonenumber;
    ObservableList<student> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ID.setCellValueFactory(new
                PropertyValueFactory<student, Integer>("ID"));
        name.setCellValueFactory(new
                PropertyValueFactory<student, String>("name"));
        DOB.setCellValueFactory(new
                PropertyValueFactory<student, Date>("DOB"));
        phonenumber.setCellValueFactory(new
                PropertyValueFactory<student, Integer>("phonenumber"));
        tableView.setItems(list);
    }


    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }

    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/lab1isha";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM student";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int ID = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                Date DOB = resultSet.getDate("DOB");
                int phonenumber = resultSet.getInt("phonenumber");
                tableView.getItems().add(new student(ID, name, DOB,
                        phonenumber));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}