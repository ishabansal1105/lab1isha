package com.example.lab1isha;

import java.util.Date;

public class student {
    private int ID;
    private String name;
    private Date DOB;
    private int phonenumber;

    public student(int ID, String name, Date DOB, int phonenumber) {
        this.ID = ID;
        this.name = name;
        this.DOB = DOB;
        this.phonenumber = phonenumber;
    }
    public int getID() {
        return ID;
    }
    public String getname() {
        return name;
    }
    public Date getDOB() {
        return DOB;
    }
    public int getphonenumber() {
        return phonenumber;
    }
}

